<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

class modCouponHelper
{
	function getCat($cat)
	{
		$db =& JFactory::getDBO();
		$query = 'SELECT id FROM #__coupon_category WHERE title = "'.$cat.'"';
		$db->setQuery( $query );
		$id = $db->loadResult();
		
		return $id ? $id : 1;
	}
	
	function getCoupons($id)	{
	
		$db =& JFactory::getDBO();
		$query = 'SELECT * FROM #__coupons WHERE cat_id = "'.$id.'" order by ordering asc limit 5';
		$db->setQuery( $query );
		$coupons = $db->loadObjectList();
		
		return $coupons;
	
	}
}
