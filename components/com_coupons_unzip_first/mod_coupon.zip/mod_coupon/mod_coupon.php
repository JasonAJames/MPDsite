<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

// Include the syndicate functions only once
require_once (dirname(__FILE__).DS.'helper.php');

$cat = $params->get('cat', '');

$id 	= modCouponHelper::getCat($cat);

$coupons = modCouponHelper::getCoupons($id);

require(JModuleHelper::getLayoutPath('mod_coupon'));