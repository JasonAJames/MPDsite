<?php // no direct access
defined('_JEXEC') or die('Restricted access'); ?>

<?php

echo '<ul>';

if(count($coupons) > 0)	{

for($i=0;$i<count($coupons);$i++)	{

	echo '<li><a href="index.php?option=com_coupon&view=cdetail&id='.$coupons[$i]->id.'">' . $coupons[$i]->name . '</a></li>';

}

}

else	{
	echo 'No Coupon found in this Category.';
}

echo '</ul>';