<?php
 
// No direct access
 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport('joomla.application.component.controller');
 
class CouponController extends JController
{
   
    function display()
    {
        parent::display();
    }
 
}
