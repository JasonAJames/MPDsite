<?php
 
// no direct access
 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport( 'joomla.application.component.view');
 
 
class CouponViewCoupon extends JView
{
    function display($tpl = null)
    {
        $model =& $this->getModel();
		$document	=& JFactory::getDocument();
		
		$document->setTitle( 'Coupons');
		
        $categories = $model->getCategories();
		
        $this->assignRef( 'categories', $categories );
		
		parent::display($tpl);

    }
}
