<?php
 
// No direct access
 
defined('_JEXEC') or die('Restricted access'); ?>

<?php

	echo '<div id="content">';

		for($i=0;$i<count($this->categories);$i++)	{
		
			echo '<h3><a href="index.php?option=com_coupon&view=detail&id='.$this->categories[$i]->id.'">' . $this->categories[$i]->title . '</a></h3>';
			echo '<p>' . $this->categories[$i]->descr . '</p>';
			
			$db =& JFactory::getDBO();
			
			$query = 'SELECT * FROM #__coupons WHERE cat_id = "'.$this->categories[$i]->id.'" order by ordering asc limit 1';
			$db->setQuery( $query );
			$coupon = $db->loadObject();
			if($coupon <> "")	{
				echo '<p>' . $coupon->descr . '</p>';
			}
			else	{
				echo '<p>Currently No Coupon available in this Category.</p>';
			}
		
		}
		
		echo '<div id="page_nav" style="text-align:right;">';
		
		$db =& JFactory::getDBO();
		
		$ls = JRequest::getVar('ls', 0, '', 'int');
		
		if($ls > 0)	{
			
			$query = 'SELECT id FROM #__coupon_category WHERE published = 1 and id < ' . $ls . ' order by id desc limit 10';
			$db->setQuery( $query );
			$data = $db->loadResultArray();
			if(count($data) > 0)	{
				$pre = $data[count($data)-1];
			}
			else	{
				$pre = NULL;
			}
			
		}
		
		else	{
			$pre = NULL;
		}
		
		if($i == 10)	{
		
			$query = 'SELECT count( * ) FROM #__coupon_category WHERE published = 1 and id > ' . $this->categories[9]->id;
			$db->setQuery( $query );
			$count = $db->loadResult();
			if($count > 0)	{
				$nxt = $this->categories[9]->id+1;
			}
			else	{
				$nxt = NULL;
			}
		
		}
		
		else	{
			$nxt = NULL;
		}
		
		if($pre <> NULL)	{
			
			echo '<a href="index.php?option=com_coupon&view=coupon&ls='.$pre.'" title="Prev"><span>&lt; Prev </span></a>';
		}
		if($nxt)	{
			echo '<a href="index.php?option=com_coupon&view=coupon&ls='.$nxt.'" title="Next" style="margin-left:5px;"><span>Next &gt; </span></a>';
		}
		echo '</div>';
	
	echo '</div>';

?>