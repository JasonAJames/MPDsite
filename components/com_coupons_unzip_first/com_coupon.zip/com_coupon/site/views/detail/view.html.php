<?php
 
// no direct access
 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport( 'joomla.application.component.view');
 

class CouponViewDetail extends JView
{
    function display($tpl = null)
    {
        $id = JRequest::getVar('id', NULL, 'get', 'int');
		
		$document	=& JFactory::getDocument();
		$model =& $this->getModel();
        $coupons = $model->getCoupons($id);
		
        $this->assignRef( 'coupons', $coupons );
		
		$cat_title = $model->getCatTitle($id);
		
		$document->setTitle( $cat_title->title);
		
		$this->assignRef( 'cat_title', $cat_title );

		
		parent::display($tpl);

    }
}
