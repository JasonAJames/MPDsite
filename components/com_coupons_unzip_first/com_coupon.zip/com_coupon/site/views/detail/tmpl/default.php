<?php
 
// No direct access
 
defined('_JEXEC') or die('Restricted access'); ?>
<style>
#content ul	{
margin:0;
}
#content ul li	{
list-style:none;
}
</style>
<?php

	echo '<div id="content">';

		echo '<h1>' . $this->cat_title->title . '</h1>';
		
		for($i=0;$i<count($this->coupons);$i++)	{
			
			$today = date("Y-m-d");
			$diff = strtotime($today) - strtotime($this->coupons[$i]->create_date);
		
			echo '<div id="couponcontainer">';
			echo '<p><span><a href="index.php?option=com_coupon&view=cdetail&id='.$this->coupons[$i]->id.'">' . $this->coupons[$i]->name . '</a> </span>';
			if($diff >= 0)	{
				echo '<span> &nbsp; <img src="'.JURI::root().'components/com_coupon/images/available.gif" alt="Available" border="0" align="bottom" /></span>';
			}
			else	{
				echo '<span> &nbsp; <img src="'.JURI::root().'components/com_coupon/images/expired.gif" alt="Available" border="0" align="bottom" /></span>';
			}
			echo '</p><br style="clear:both;" />';
			
			echo $this->coupons[$i]->descr;
			
			echo '</div>';
		
		}
		
		echo '<div id="page_nav" style="text-align:right;">';
		
		$db =& JFactory::getDBO();
		
		$ls = JRequest::getVar('ls', 0, '', 'int');
		
		if($ls > 0)	{
			
			$query = 'SELECT id FROM #__coupons WHERE published = 1 and cat_id = "'.$this->cat_title->id.'" and id < ' . $ls . ' order by id desc limit 10';
			$db->setQuery( $query );
			$data = $db->loadResultArray();
			
			if(count($data) > 0)	{
				$pre = $data[count($data)-1];
			}
			else	{
				$pre = NULL;
			}
			
		}
		
		else	{
			$pre = NULL;
		}
		
		if($i == 10)	{
		
			$query = 'SELECT count( * ) FROM #__coupons WHERE published = 1 and id > ' . $this->coupons[9]->id;
			$db->setQuery( $query );
			$count = $db->loadResult();
			if($count > 0)	{
				$nxt = $this->coupons[9]->id+1;
			}
			else	{
				$nxt = NULL;
			}
		
		}
		
		else	{
			$nxt = NULL;
		}
		
		if($pre)	{
			echo '<a href="index.php?option=com_coupon&view=detail&id='.$this->cat_title->id.'&ls='.$pre.'" title="Prev"><span>&lt; Prev </span></a>';
		}
		if($nxt)	{
			echo '<a href="index.php?option=com_coupon&view=detail&id='.$this->cat_title->id.'&ls='.$nxt.'" title="Next" style="margin-left:5px;"><span>Next &gt; </span></a>';
		}
		
		echo '</div>';
	
	echo '</div>';

?>