<?php
 
// no direct access
 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport( 'joomla.application.component.view');
 
 
class CouponViewCdetail extends JView
{
    function display($tpl = null)
    {
        $id = JRequest::getVar('id', NULL, 'get', 'int');
		
		$document	=& JFactory::getDocument();
		$model =& $this->getModel();
        $coupon = $model->getCoupon($id);
		
		$document->setTitle( $coupon->name);
		
        $this->assignRef( 'coupon', $coupon );
		
		
		parent::display($tpl);

    }
}
