<?php
 
// No direct access
 
defined('_JEXEC') or die('Restricted access'); ?>
<style>
#content ul	{
margin:0;
}
#content ul li	{
list-style:none;
}
</style>

	<div id="content">

<?php
		
		echo '<h1>' . $this->coupon->name . '</h1>';
		
			
			echo '<div style="float:left;width:60%;">';
			
			$today = date("Y-m-d");
			$diff = strtotime($today) - strtotime($this->coupon->create_date);
			
			echo '<ul>';
			
				echo '<li><strong>Company Name: </strong>' . $this->coupon->comp_name . '</li>';
				echo '<li><strong>Product Name: </strong>' . $this->coupon->prod_name . '</li>';
				
				if($diff >= 0)	{
					echo '<li><strong>Available: </strong>Yes' . '</li>';
				}
				else	{
					echo '<li><strong>Available: </strong>No';
				}
				
				echo '<li><strong>Valid for Locations: </strong>' . $this->coupon->valid_loc . '</li>';
				
				echo '<li><strong>Website: </strong>' . $this->coupon->website . '</li>';
				
				echo '<li><strong>Description: </strong>' . $this->coupon->descr . '</li>';
				
				if($this->coupon->cond <> "")	{
					echo '<li><strong>Other Conditions: </strong>' . $this->coupon->cond . '</li>';
				}
			
			echo '</ul>';
						
			echo '</div>';
			
			echo '<div style="float:left;width:35%;">';
			if($this->coupon->descr <> "")	{
			?>
			
			<a href="#" title="Print" onclick="window.open('<?php echo JURI::root(); ?>components/com_coupon/views/cdetail/tmpl/image.php','win2','width=400,height=400,left=100,top=100');return false;"><img src="<?php echo JURI::root(); ?>components/com_coupon/images/print.gif" alt="Print" align="right"></a><br />

			<?php
			
			echo '<p>' . $this->coupon->img . '</p>';
			setcookie('image', base64_encode($this->coupon->img), time()+600, '/');
			setcookie('img_path', base64_encode(JURI::root()), time()+600, '/');
			}
			else	{
				echo '<p><img src="'.JURI::root().'components/com_coupon/images/image-not-available.gif" border="0" alt="Image not available" width="100" height="100" /></p>';
			}
			echo '</div>';
			
?>
</div>