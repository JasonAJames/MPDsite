<a href="#" onclick="window.print();return false;"><img src="../../../images/printButton.png" alt="Print" align="top"></a>
<p>

<?php

	$data = base64_decode($_COOKIE['image']);
	$path = base64_decode($_COOKIE['img_path']);
	
	echo str_replace('src="', 'src="'.$path, $data);

?>
</p>