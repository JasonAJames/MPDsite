<?php
 
// No direct access
 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport( 'joomla.application.component.model' );
 
class CouponModelCoupon extends JModel
{
    /**
    * Gets the greeting
    * @return string The greeting to be displayed to the user
    */
    function getCategories()
    {
        $db =& JFactory::getDBO();
 		$ls = JRequest::getVar('ls', 0, '', 'int');
  	 	$query = 'SELECT * FROM #__coupon_category WHERE published = 1 and id >= "' . $ls . '" order by id asc limit 10';
   		$db->setQuery( $query );
   		$categories = $db->loadObjectList();
 
   		return $categories;

    }
	
		
}
