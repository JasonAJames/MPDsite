<?php
 
// No direct access
 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport( 'joomla.application.component.model' );
 

class CouponModelDetail extends JModel
{
   
    function getCoupons($id)
    {
		$db =& JFactory::getDBO();
		
		$ls = JRequest::getVar('ls', 0, '', 'int');
 
  	 	$query = 'SELECT * FROM #__coupons WHERE published = 1 and cat_id = "' . $id . '" and id >= "'.$ls.'" order by id asc limit 10';
   		$db->setQuery( $query );
   		$coupons = $db->loadObjectList();
 
   		return $coupons;

    }
	
	function getCatTitle($id)	{
	
		$db =& JFactory::getDBO();
		
		$query = 'SELECT * FROM #__coupon_category WHERE id = "'.$id.'"';
		$db->setQuery( $query );
		$cat_title = $db->loadObject();
		
		return $cat_title;
	
	}
	
}
