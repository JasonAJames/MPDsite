<?php
 
// No direct access
 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport( 'joomla.application.component.model' );
 
class CouponModelCdetail extends JModel
{
    
    function getCoupon($id)
    {
		$db =& JFactory::getDBO();
 
  	 	$query = 'SELECT * FROM #__coupons WHERE published = 1 and id = "' . $id . '" order by ordering asc';
   		$db->setQuery( $query );
   		$coupon = $db->loadObject();
 
   		return $coupon;

    }
	
}
