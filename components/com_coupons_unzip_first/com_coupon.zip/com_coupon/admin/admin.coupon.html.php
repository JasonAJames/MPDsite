<?php


// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );


class coupon_html
{

	function showCateogry($data)	{	?>
	
		<table class="adminlist">
		<thead>
			<tr>
				<th width="5" align="left">
					<?php echo JText::_( 'Num' ); ?>
				</th>
				<th width="3%">
					<?php echo JText::_( 'Edit' ); ?>
				</th>
				<th class="title" width="70%">
					<?php echo JText::_( 'Title' ); ?>
				</th>
				<th class="title" width="20">
					<?php echo JText::_( 'Coupons' ); ?>
				</th>
				<th class="title" width="20">
					<?php echo JText::_( 'Published' ); ?>
				</th>
				<th width="5" nowrap="nowrap">
					<?php echo JText::_( 'ID' ); ?>
				</th>
			</tr>
		</thead>
		<tbody>
		<?php for($i=0;$i<count($data);$i++)	{
		
			$db =& JFactory::getDBO();
			$query = 'SELECT count( * ) FROM #__coupons WHERE cat_id = "'.$data[$i]->id.'"';
			$db->setQuery( $query );
			$coupons = $db->loadResult();
		
		?>
			<tr>
				<td><?php echo $i+1; ?></td>
				<td><input type="checkbox" name="cid[]" value="<?php echo $data[$i]->id; ?>" /></td>
				<td><?php echo $data[$i]->title; ?></td>
				<td><a href="index.php?option=com_coupon&section=coupon&cid=<?php echo $data[$i]->id;?>"><?php echo '<img src="../includes/js/ThemeOffice/mainmenu.png" border="0">'; ?></a> &nbsp; <a href="index.php?option=com_coupon&section=coupon&cid=<?php echo $data[$i]->id;?>"> <?php echo $coupons; ?></a></td>
				<td align="center"><?php $task = $data[$i]->published == 1?'unpublish':'publish'; $txt = $data[$i]->published == 1?'Published':'Unpublished'; $img = $data[$i]->published == 1?'publish_g.png':'publish_x.png'; echo '<a href="index.php?option=com_coupon&section=category&task=' . $task . '&cid=' . $data[$i]->id . '"><img src="images/' . $img . '" alt="' . $txt . '" border="0" width="16" height="16" /></a>'; ?></td>
				<td><?php echo $data[$i]->id; ?></td>
			</tr>
		<?php	}	?>
		</tbody>
		</table>
	
	<?php	}
	
	function showCoupon($data)	{
	$cid = JRequest::getVar( 'cid', 1, 'get', 'int' );	?>
	
		<table class="adminlist">
		<thead>
			<tr>
				<th width="5" align="left">
					<?php echo JText::_( 'Num' ); ?>
				</th>
				<th width="3%">
					<?php echo JText::_( 'Edit' ); ?>
				</th>
				<th class="title" width="25%">
					<?php echo JText::_( 'Coupon Name' ); ?>
				</th>
				<th class="title" width="25%">
					<?php echo JText::_( 'Company Name' ); ?>
				</th>
				<th class="title" width="25%">
					<?php echo JText::_( 'Product Name' ); ?>
				</th>
				<th class="title" width="50">
					<?php echo JText::_( 'Validity Period' ); ?>
				</th>
				<th class="title" width="20">
					<?php echo JText::_( 'Published' ); ?>
				</th>
				<th width="5" nowrap="nowrap">
					<?php echo JText::_( 'ID' ); ?>
				</th>
			</tr>
		</thead>
		<tbody>
		<?php for($i=0;$i<count($data);$i++)	{	?>
			<tr>
				<td><?php echo $i+1; ?></td>
				<td><input type="checkbox" name="id[]" value="<?php echo $data[$i]->id; ?>" /></td>
				<td><?php echo $data[$i]->name; ?></td>
				<td><?php echo $data[$i]->comp_name; ?></td>
				<td><?php echo $data[$i]->prod_name; ?></td>
				<td><?php echo $data[$i]->validity; ?></td>
				<td align="center"><?php $task = $data[$i]->published == 1?'unpublish':'publish'; $txt = $data[$i]->published == 1?'Published':'Unpublished'; $img = $data[$i]->published == 1?'publish_g.png':'publish_x.png'; echo '<a href="index.php?option=com_coupon&section=coupon&task=' . $task . '&&cid='.$cid.'&id=' . $data[$i]->id . '"><img src="images/' . $img . '" alt="' . $txt . '" border="0" width="16" height="16" /></a>'; ?></td>
				<td><?php echo $data[$i]->id; ?></td>
			</tr>
		<?php	}	?>
		</tbody>
		</table>
	<input type="hidden" name="cid" value="<?php echo $cid; ?>" />
	<?php	}
	
	function editCategory($data)	{
	
	if($data)	{	?>
	
	<table class="admintable">
  <tr>
    <td class="key">Title:</td>
    <td colspan="2"><input type="text" name="title" value="<?php echo $data->title; ?>" /></td>
  </tr>
  <tr>
    <td class="key">Description:</td>
    <td colspan="2" valign="middle">
	<?php
		$editor =& JFactory::getEditor();
		echo $editor->display( 'descr',  $data->descr, '550', '300', '60', '20', false ) ;
	?></td>
  </tr>
   <tr>
    <td class="key">Published:</td>
    <td colspan="2">
	<input type="radio" name="published" value="1" <?php if($data->published == 1) echo 'checked="checked"'; ?> /> Yes
	<input type="radio" name="published" value="0" <?php if($data->published == 0) echo 'checked="checked"'; ?> /> No
	</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="hidden" name="section" value="category" /><input type="hidden" name="cid" value="<?php echo $data->id; ?>" /></td>
  </tr>
</table>
	
	<?php
	}
	else	{	?>
	
	<table class="admintable">
  <tr>
    <td class="key">Title:</td>
    <td colspan="2"><input type="text" name="title" /></td>
  </tr>
  <tr>
    <td class="key">Description:</td>
    <td colspan="2" valign="middle">
	<?php
		$editor =& JFactory::getEditor();
		echo $editor->display( 'descr', '', '550', '300', '60', '20', false ) ;
	?></td>
  </tr>
   <tr>
    <td class="key">Published:</td>
    <td colspan="2">
	<input type="radio" name="published" value="1" /> Yes
	<input type="radio" name="published" value="0" /> No
	</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="hidden" name="section" value="category" /><input type="hidden" name="cid" value="" /></td>
  </tr>
</table>

<?php	}	}

	function editCoupon($data)	{
	
		if($data)	{	?>
		
			<table class="admintable">
  <tr>
    <td class="key">Coupon Name:</td>
    <td colspan="2"><input type="text" name="name" value="<?php echo $data->name; ?>" /></td>
  </tr>
  <tr>
    <td class="key">Company Name:</td>
    <td colspan="2"><input type="text" name="comp_name" value="<?php echo $data->comp_name; ?>" /></td>
  </tr>
  <tr>
    <td class="key">Product Name:</td>
    <td colspan="2"><input type="text" name="prod_name" value="<?php echo $data->prod_name; ?>" /></td>
  </tr>
  <tr>
    <td class="key">Validity Period:</td>
    <td colspan="2"><input type="text" name="validity" value="<?php echo $data->validity; ?>" /> <span class="hasTip" title="Enter the number in Days."><img src="templates/khepri/images/menu/icon-16-info.png" border="0" alt="info" align="top" /></span></td>
  </tr>
  <tr>
    <td class="key">Valid for Location:</td>
    <td colspan="2"><textarea name="valid_loc"><?php echo $data->valid_loc; ?></textarea> <span class="hasTip" title="Enter the locations where the coupon the coupon is valid."><img src="templates/khepri/images/menu/icon-16-info.png" border="0" alt="info" align="top" /></span></td>
  </tr>
  <tr>
    <td class="key">Website:</td>
    <td colspan="2"><input type="text" name="website" value="<?php echo $data->website; ?>" /></td>
  </tr>
  <tr>
    <td class="key">Description:</td>
    <td colspan="2" valign="middle">
	<?php
		$editor =& JFactory::getEditor();
		echo $editor->display( 'descr',  $data->descr, '550', '300', '60', '20', array('readmore') ) ;
	?></td>
  </tr>
  <tr>
    <td class="key">Image:</td>
    <td colspan="2" valign="middle">
	<?php
		$editor =& JFactory::getEditor();
		echo $editor->display( 'img',  $data->img, '550', '300', '60', '20', array('pagebreak', 'readmore') ) ;
	?></td>
  </tr>
  <tr>
    <td class="key">Any other Conditions:</td>
    <td colspan="2"><textarea name="cond"><?php echo $data->cond; ?></textarea></td>
  </tr>
   <tr>
    <td class="key">Published:</td>
    <td colspan="2">
	<input type="radio" name="published" value="1" <?php if($data->published == 1) echo 'checked="checked"'; ?> /> Yes
	<input type="radio" name="published" value="0" <?php if($data->published == 0) echo 'checked="checked"'; ?> /> No
	</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="hidden" name="section" value="category" /><input type="hidden" name="cid" value="<?php echo $data->cat_id; ?>" /><input type="hidden" name="id" value="<?php echo $data->id; ?>" /></td>
  </tr>
</table>
		
		<?php	}
		
		else	{	?>
		
			<table class="admintable">
  <tr>
    <td class="key">Coupon Name:</td>
    <td colspan="2"><input type="text" name="name" /></td>
  </tr>
  <tr>
    <td class="key">Company Name:</td>
    <td colspan="2"><input type="text" name="comp_name" /></td>
  </tr>
  <tr>
    <td class="key">Product Name:</td>
    <td colspan="2"><input type="text" name="prod_name" /></td>
  </tr>
  <tr>
    <td class="key">Validity Period:</td>
    <td colspan="2"><input type="text" name="validity" /> <span class="hasTip" title="Enter the number in Days."><img src="templates/khepri/images/menu/icon-16-info.png" border="0" alt="info" align="top" /></span></td>
  </tr>
  <tr>
    <td class="key">Valid for Location:</td>
    <td colspan="2"><textarea name="valid_loc"></textarea> <span class="hasTip" title="Enter the locations where the coupon the coupon is valid."><img src="templates/khepri/images/menu/icon-16-info.png" border="0" alt="info" align="top" /></span></td>
  </tr>
  <tr>
    <td class="key">Website:</td>
    <td colspan="2"><input type="text" name="website" /></td>
  </tr>
  <tr>
    <td class="key">Description:</td>
    <td colspan="2" valign="middle">
	<?php
		$editor =& JFactory::getEditor();
		echo $editor->display( 'descr',  '', '550', '300', '60', '20', array('readmore')) ;
	?></td>
  </tr>
  <tr>
    <td class="key">Image:</td>
    <td colspan="2" valign="middle">
	<?php
		$editor =& JFactory::getEditor();
		echo $editor->display( 'img',  '', '550', '300', '60', '20', array('pagebreak', 'readmore') ) ;
	?></td>
  </tr>
  <tr>
    <td class="key">Any other Conditions:</td>
    <td colspan="2"><textarea name="cond"></textarea></td>
  </tr>
   <tr>
    <td class="key">Published:</td>
    <td colspan="2">
	<input type="radio" name="published" value="1" /> Yes
	<input type="radio" name="published" value="0" /> No
	</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="hidden" name="section" value="category" /><input type="hidden" name="id" value="" /><input type="hidden" name="cid" value="<?php echo JRequest::getVar('cid', 1, 'post', 'int'); ?>" /></td>
  </tr>
</table>
		
		<?php	}
	
	}
	
}