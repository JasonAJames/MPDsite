CREATE TABLE IF NOT EXISTS `#__coupons` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `cat_id` int(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `comp_name` varchar(255) NOT NULL,
  `prod_name` varchar(255) NOT NULL,
  `validity` varchar(255) NOT NULL,
  `valid_loc` text NOT NULL,
  `website` varchar(255) NOT NULL,
  `cond` text NOT NULL,
  `create_date` date NOT NULL,
  `published` tinyint(1) NOT NULL,
  `ordering` int(100) NOT NULL,
  `descr` mediumtext NOT NULL,
  `img` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `#__coupon_category` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `ordering` int(100) NOT NULL,
  `descr` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;