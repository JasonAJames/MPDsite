<?php


// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

require_once( JApplicationHelper::getPath( 'admin_html' ) );

JToolBarHelper::title( JText::_( 'Coupon Manager' ), 'generic.png' );

JHTML::_('behavior.tooltip');

// get parameters from the URL or submitted form
$section 	= JRequest::getCmd( 'section', 'category' );
$task 		= JRequest::getCmd( 'task', 'show' );
$taskp		= JRequest::getCmd( 'taskp', 'show' );
$cid 		= JRequest::getVar( 'cid', array(0), '', 'array' );
$id 		= JRequest::getVar( 'id', array(0), '', 'array' );
$do			= JRequest::getVar('do', 'post');
JArrayHelper::toInteger($cid, array(0));
JArrayHelper::toInteger($id, array(0));
if($do == 'saveorder')	{
	$task = 'order';
}
?>
<form action="index.php?option=com_coupon" method="post">
<div id="toolbar-box" style="border:#ddd solid 1px; padding:5px; -moz-border-radius:5px; height:18px;">
<?php if($section == "coupon")	{	?>
<div style="float:left; width:40%;">
<a href="index.php?option=com_coupon">Back to Category</a>
</div>
<?php	}	?>
<div style="float:right; width:40%; text-align:right;">
<?php

		switch ( $taskp )	{
		
			case 'show' :
			echo '<input type="submit" name="taskp" value="Publish" /> <input type="submit" name="taskp" value="Unpublish" /> <input type="submit" name="taskp" value="Remove" /> <input type="submit" name="taskp" value="Edit" /> <input type="submit" name="taskp" value="New" />';
			break;
			
			case 'Publish' :
			$task = 'publish';
			break;
			
			case 'Unpublish' :
			$task = 'unpublish';
			break;
			
			case 'Remove' :
			$task = 'remove';
			break;
			
			case 'Edit' :
			echo '<input type="submit" name="taskp" value="Save" /> <input type="submit" name="taskp" value="Close" />';
			$task = 'edit';
			$do = 1;
			break;
			
			case 'New' :
			echo '<input type="submit" name="taskp" value="Save" /> <input type="submit" name="taskp" value="Cancel" />';
			$task = 'new';
			break;
			
			case 'Cancel' :
			case 'Close' :
			$task = 'cancel';
			break;
			
			case 'Save' :
			$task = 'save';
			break;
			
			default :
			echo '<input type="submit" name="taskp" value="Publish" /> <input type="submit" name="taskp" value="Unpublish" /> <input type="submit" name="taskp" value="Remove" /> <input type="submit" name="taskp" value="Edit" /> <input type="submit" name="taskp" value="New" />';
			break;
		
		}

?>
</div>
</div>
<?php

switch ( $section )	{
	
	case 'category' :

	switch ( $task )	{

		case 'show' :
		show($section, NULL);
		break;
		
		case 'edit' :
		editCategory($cid, true);
		break;
		
		case 'new' :
		editCategory(false, false);
		break;
		
		case 'save' :
		saveCategory($cid);
		break;
		
		case 'cancel' :
		case 'close' :
		cancel($section, NULL);
		break;
		
		case 'publish' :
		publish($section, $cid, NULL, 1);
		break;
		
		case 'unpublish' :
		publish($section, $cid, NULL, 0);
		
		case 'remove' :
		remove($section, $cid);
		break;
		
		case 'order' :
		saveOrder($section);
		break;
		
		default :
		show($section, NULL);
		break;

	}
	
	break;
	
	case 'coupon' :
	
	switch ( $task )	{
	
		case 'show' :
		show($section, $cid);
		break;
		
		case 'edit' :
		editCoupon($cid, $id, true);
		break;
		
		case 'new' :
		editCoupon($cid, false, false);
		break;
		
		case 'save' :
		saveCoupon($cid, $id);
		break;
		
		case 'cancel' :
		cancel($section, $cid);
		break;
		
		case 'publish' :
		publish($section, $cid, $id, 1);
		break;
		
		case 'unpublish' :
		publish($section, $cid, $id, 0);
		break;
		
		case 'remove' :
		remove($section, $cid, $id);
		break;
		
		case 'order' :
		saveOrder($section, $cid);
		break;
		
		default :
		showCoupon($cid);
		break;
	
	}
	
	break;
	
	default :
	showCategory();
	break;
	
}


function show($section, $cid)	{

	$db =& JFactory::getDBO();
	
	if($section == "category")	{
		$query = 'SELECT * FROM #__coupon_category order by id asc';
	}
	else	{
		$query = 'SELECT * FROM #__coupons WHERE cat_id = "'.$cid[0].'" order by id asc';
	}
	
	$db->setQuery( $query );
	$data = $db->loadObjectList();
	
	if($section == "category")	{
		coupon_html::showCateogry($data);
	}
	else	{
		coupon_html::showCoupon($data);
	}

}

function editCategory($cid, $do)	{

	$db =& JFactory::getDBO();
	if($do)	{
		$query = 'SELECT * FROM #__coupon_category WHERE id = "'.$cid[0].'"';
		$db->setQuery( $query );
		$data = $db->loadObject();
	}
	else	{
		$data = false;
	}
	
	coupon_html::editCategory($data);

}

function saveCategory($cid)	{

	$db =& JFactory::getDBO();
	global $mainframe;
	
	$post = JRequest::get('post');
	if($post["cid"] == "")	{
		$query = 'INSERT INTO #__coupon_category (title, descr, published) VALUES ("'.$post["title"].'", "'.$post["descr"].'", "'.$post["published"].'")';
	}
	else	{
		$query = 'UPDATE #__coupon_category SET title = "'.$post["title"].'", descr = "'.$post["descr"].'", published = "'.$post["published"].'" WHERE id = "'.$post["cid"].'"';
	}
	
	$db->setQuery( $query );
	
	if($db->query())	{
		$msg = 'Category saved successfully.';
	}
	else	{
		$msg = $db->getErrorMsg();
	}
	
	$mainframe->redirect( 'index.php?option=com_coupon', $msg);

}

function editCoupon($cid, $id, $do)	{

	$db =& JFactory::getDBO();
	if($do)	{
		$query = 'SELECT * FROM #__coupons WHERE id = "'.$id[0].'"';
		$db->setQuery( $query );
		$data = $db->loadObject();
	}
	else	{
		$data = false;
	}
	
	coupon_html::editCoupon($data);

}

function saveCoupon($cid, $id)	{

	$db =& JFactory::getDBO();
	global $mainframe;
	
	$post = JRequest::get('post');
	
	$post["descr"] = JRequest::getVar('descr', '', 'post', 'string', JREQUEST_ALLOWRAW);
	$post["img"] = JRequest::getVar('img', '', 'post', 'string', JREQUEST_ALLOWRAW);
	
	if($post["id"] == "")	{
		$create_date = date("Y-m-d");
		$insert = new stdClass;
		
		$insert->id 		= NULL;
		$insert->cat_id 	= $post["cid"];
		$insert->name 		= $post["name"];
		$insert->comp_name 	= $post["comp_name"];
		$insert->prod_name 	= $post["prod_name"];
		$insert->validity 	= $post["validity"];
		$insert->valid_loc 	= $post["valid_loc"];
		$insert->website 	= $post["website"];
		$insert->descr 		= $post["descr"];
		$insert->img 		= $post["img"];
		$insert->cond 		= $post["cond"];
		$insert->create_date = $create_date;
		$insert->published 	= $post["published"];
		
		if($db->insertObject( '#__coupons', $insert, 'id' ))	{
			$msg = 'Coupon saved successfully.';
		}
		else	{
			$msg = 'Sorry! Some Database error occurred.';
		}
	}
	else	{
	
		$update = new stdClass;
		
		$update->id 		= $post["id"];
		$update->cat_id 	= $post["cid"];
		$update->name 		= $post["name"];
		$update->comp_name 	= $post["comp_name"];
		$update->prod_name 	= $post["prod_name"];
		$update->validity 	= $post["validity"];
		$update->valid_loc 	= $post["valid_loc"];
		$update->website 	= $post["website"];
		$update->descr 		= $post["descr"];
		$update->img 		= $post["img"];
		$update->cond 		= $post["cond"];
		$update->published 	= $post["published"];
		
		if($db->updateObject( '#__coupons', $update, 'id' ))	{
			$msg = 'Coupon updated successfully.';
		}
		else	{
			$msg = $db->stderr();
		}
	}
	
	$mainframe->redirect( 'index.php?option=com_coupon&section=coupon&cid='.$post["cid"], $msg);

}

function cancel($section, $cid = NULL)	{

	global $mainframe;
	$msg = 'Operation canceled.';
	if($section == "coupon")	{
		$mainframe->redirect( 'index.php?option=com_coupon&task=show&section=coupon&cid='.$cid[0], $msg);
	}
	else	{
		$mainframe->redirect( 'index.php?option=com_coupon', $msg);
	}

}

function remove($section, $cid, $id)	{

	$db =& JFactory::getDBO();
	global $mainframe;
	
	if($section == "coupon")	{
		if(is_array($id))	{
			$id = implode(', ', $id);
		}
	
		$query = 'DELETE FROM #__coupons WHERE id IN ( ' . $id . ' )';
		
		$db->setQuery( $query );
	
		if($db->query())	{
			$msg = 'Coupon removed successfully.';
		}
		else	{
			$msg = $db->getErrorMsg();
		}
		$mainframe->redirect( 'index.php?option=com_coupon&section=coupon&cid='.$cid[0], $msg);
	}
	else	{
		if(is_array($cid))	{
			$cid = implode(', ', $cid);
		}
		
		$query = 'DELETE FROM #__coupon_category WHERE id IN ( ' . $cid . ' )';
		
		$db->setQuery( $query );
	
		if($db->query())	{
			$msg = 'Removed successfully.';
		}
		else	{
			$msg = $db->getErrorMsg();
		}
		$mainframe->redirect( 'index.php?option=com_coupon', $msg);
	}
	
	
}

function publish($section, $cid, $id, $do = 1)	{

	$db =& JFactory::getDBO();
	global $mainframe;
	
	if($section == "coupon")	{
		if(is_array($id))	{
			$id = implode(', ', $id);
		}
		$query = 'UPDATE #__coupons SET published = "'.$do.'" WHERE id IN ( ' . $id . ' )';
		
		$db->setQuery( $query );
	
		if($db->query())	{
			$msg = 'Updated successfully.';
		}
		else	{
			$msg = $db->getErrorMsg();
		}
		$mainframe->redirect( 'index.php?option=com_coupon&section=coupon&cid='.$cid[0], $msg);
		
	}
	
	else	{
		if(is_array($cid))	{
			$cid = implode(', ', $cid);
		}
		$query = 'UPDATE #__coupon_category SET published = "' .$do. '" WHERE id IN ( ' . $cid . ' )';
		
		$db->setQuery( $query );
	
		if($db->query())	{
			$msg = 'Updated successfully.';
		}
		else	{
			$msg = 'Sorry! Some Database error occurred.';
		}
		$mainframe->redirect( 'index.php?option=com_coupon', $msg);
	
	}
	
	
}

function saveOrder($section, $cid)	{

	$db = &JFactory::getDBO();
	global $mainframe;
	$ordering = JRequest::getVar('ordering', array(0), 'post', 'array');
	
	if($section == "coupon")	{
		
		$query = 'SELECT id FROM #__coupons WHERE cat_id = "'.$cid[0].'" order by ordering asc';
		$db->setQuery( $query );
		$id = $db->loadResultArray();
		
		for($i=0;$i<count($id);$i++)	{
			$query = 'UPDATE #__coupons SET ordering = "'.$ordering[$i].'" WHERE id = "' . $id[$i] . '"';
			$db->setQuery( $query );
			if($db->query())	{
				$count++;
			}
		}
		if($count == count($id))	{
			$msg = 'Ordering saved successfully.';
		}
		else	{
			$msg = $db->getErrorMsg();
		}
		
		$mainframe->redirect( 'index.php?option=com_coupon&section=coupon&cid='.$cid[0], $msg);
	}
	else	{
		
		$query = 'SELECT id FROM #__coupon_category order by ordering asc';
		$db->setQuery( $query );
		$cid = $db->loadResultArray();
		
		for($i=0;$i<count($cid);$i++)	{
			$query = 'UPDATE #__coupon_category SET ordering = "'.$ordering[$i].'" WHERE id = "' . $cid[$i] . '"';
			$db->setQuery( $query );
			if($db->query())	{
				$count++;
			}
		}
		if($count == count($cid))	{
			$msg = 'Ordering saved successfully.';
		}
		else	{
			$msg = $db->getErrorMsg();
		}
		$mainframe->redirect( 'index.php?option=com_coupon', $msg);
	}

}

?>
<input type="hidden" name="section" value="<?php echo $section ; ?>" />
</form>